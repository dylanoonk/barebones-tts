"""
Barebones Text To Speech — web build.

A text-to-speech system built from first principles (formant synthesis over
ARPAbet phonemes). This wheel packages the project for Pyodide so it can run
entirely inside a web browser: numpy + scipy come from the Pyodide
distribution, and audio output is handled by the browser (Web Audio API)
rather than sounddevice.

Typical use from the browser glue code:

    from barebones_tts import barebones_tts

    tts = barebones_tts()
    audio = tts.render("Hello world.")   # float64 numpy array, 22050 Hz
    filename = tts.save("Hello world.")  # writes a .wav to the Pyodide FS

Differences from the desktop version (kept as small as possible):
  * pronunciation data ships inside the package (barebones_tts/data/)
  * colorama is replaced by a tiny internal ANSI shim (barebones_tts/_ansi.py)
  * FormantSynthesizer.play() raises, because sounddevice cannot run in a
    browser — play rendered audio with the Web Audio API instead.
"""

from .core import barebones_tts

__all__ = ["barebones_tts"]
__version__ = "0.1.0"
