"""
Tiny stand-in for colorama's `Fore`, used so the package only depends on
numpy + scipy. The escape codes are standard SGR sequences; the website's
console renders them as colors.
"""


class _Color:
    RESET = "\x1b[0m"
    BLACK = "\x1b[30m"
    RED = "\x1b[31m"
    GREEN = "\x1b[32m"
    YELLOW = "\x1b[33m"
    BLUE = "\x1b[34m"
    MAGENTA = "\x1b[35m"
    CYAN = "\x1b[36m"
    WHITE = "\x1b[37m"


Fore = _Color()


def init():
    """colorama.init() equivalent — a no-op for the browser build."""
    pass
